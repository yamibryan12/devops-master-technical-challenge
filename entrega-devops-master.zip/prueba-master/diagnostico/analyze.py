#!/usr/bin/env python3
import csv,collections,pathlib,statistics,json
base=pathlib.Path(__file__).resolve().parents[1]/'starter/ejercicios/master'
def read(name):
 with (base/name).open(newline='') as f:return list(csv.DictReader(f))
teams=read('org-teams.csv'); incidents=read('org-incidents.csv')
deploys=sum(int(t['deploys_per_week']) for t in teams)
weighted=sum(int(t['deploys_per_week'])*float(t['change_fail_pct']) for t in teams)/deploys
causes=collections.Counter(i['root_cause'] for i in incidents)
sevs=collections.Counter(i['severity'] for i in incidents)
by_team=collections.defaultdict(list)
for i in incidents:by_team[i['team']].append(float(i['duration_hours']))
print('Squads:',len(teams),'Deploys/week:',deploys,'CFR ponderado declarado:',round(weighted,2),'%')
print('Incidentes:',len(incidents),'Severidades:',dict(sevs),'Causas:',dict(causes))
print('Equipos sin pipeline:',[t['team'] for t in teams if t['pipeline']=='none'])
print('CFR/MTTR declarado vs incidente (duración media, NO MTTR validado):')
for t in teams:
 ds=by_team[t['team']]
 print(f"{t['team']:<17} CFR={t['change_fail_pct']:>2}% MTTR_decl={t['mttr_hours']:>4}h incidencias={len(ds):>2} duracion_media={round(statistics.mean(ds),2) if ds else 'N/D'}h")
