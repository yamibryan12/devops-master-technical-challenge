# Diagnóstico ejecutivo y roadmap de 12 meses

## Decisión solicitada al CIO

Aprobar una transformación incremental de ingeniería de plataforma, financiada inicialmente con el equipo existente de 6 FTE, priorizando ledger, data-platform y reporting y los controles de seguridad por riesgo. No proponer migración multicloud ni reescritura integral en el primer semestre. Las fechas son relativas a M1 (inicio aprobado); las auditorías son trimestrales y deben confirmarse con GRC.

## Línea base verificable y contradicciones

Se analizaron los 12 registros de `org-teams.csv` y los 30 de `org-incidents.csv` mediante `diagnostico/analyze.py`. Los squads declaran **63 despliegues por semana** y un **CFR ponderado por despliegues de ~9,81%**; es un proxy, NO un CFR observado de fallos sobre cambios reales, porque faltan registros individuales de despliegues, su período y relación causal con incidentes. El objetivo CIO de CFR global <15% aparenta ya cumplirse con el proxy, pero **no está demostrado**. Antes de declarar cumplimiento se debe instrumentar el denominador real y definiciones homogéneas.

El registro contiene **30 incidentes y 6 Sev1**. Sus principales causas son 14 cambios manuales en producción y 7 despliegues sin pruebas: **21/30 (70%)**. Hay 5 squads con Jenkins, 5 con GitHub Actions y 2 sin pipeline; el problema principal es control y adopción, no falta de una herramienta nueva. `data-platform` declara CFR 31%, MTTR 16 h y no tiene pipeline; `reporting` CFR 27%, MTTR 12 h; `ledger` CFR 24%, MTTR 9 h. Estos tres requieren intervención prioritaria, pero no son necesariamente los de más despliegues. Una organización que declara RTO 4 h y RPO 15 min mientras mantiene AKS en una sola región y DR no probado **no aporta evidencia suficiente** de cumplimiento de continuidad.

Los MTTR declarados no deben compararse sin más con las duraciones medias de incidencias: sin hora de inicio de degradación, hora de restauración validada y definiciones comunes no es el mismo indicador. Para auditoría, cada release debe estar vinculado a un pipeline y artefactos de SAST/SCA verificables: hoy existen equipos sin escaneo y sin pipeline, luego no puede afirmarse 100% de cobertura.

## Priorización, coste de oportunidad y secuencia

| Prioridad / período | Iniciativa | Impacto / riesgo / esfuerzo | Verificación |
|---|---|---|---|
| P0 M1–M2 | Telemetría centralizada de cambios, incidentes, Sev1, SAST/SCA y auditoría de pipelines; bloquear cambios manuales en servicios críticos | Muy alto / reduce incertidumbre / medio | Dashboard con numeradores y denominadores + trazas por release |
| P0 M1–M3 | Golden pipeline con controles bloqueantes según tier; piloto ledger y data-platform | Muy alto / frena fallos críticos / medio | 100% de releases piloto con evidencia SAST/SCA y aprobación |
| P0 M1–M3 | Simulacro DR, respaldos externos y runbooks medibles para sistemas críticos | Alto / riesgo continuidad / medio | Resultados medidos RTO/RPO y acciones remediadas |
| P1 M3–M6 | Migración gradual de equipos sin pipeline, control de cambios y testing; reporting después | Alto / reduce errores / medio | Squads sin pipeline: 2→0; cambios manuales con excepción documentada |
| P1 M4–M9 | Plantillas autoservicio, despliegues progresivos, rollback y métricas | Alto / reduce lead time / medio | Adopción voluntaria + menor tiempo de restauración |
| P2 M7–M12 | Mejoras HA por SLO, caos controlado y reducción de deuda de CI | Alto / esfuerzo alto / medio | SLOs medidos, experimentos repetibles, juegos de incidentes |

No se hará inicialmente: migración masiva Jenkins→GitHub en bloque; activo-activo multicloud; reemplazo integral del stack; requisitos tier0 idénticos para herramientas internas. Con 6 FTE, estas iniciativas consumirían capacidad sin asegurar mejoras tempranas. Roles propuestos: 2 CI/políticas, 2 fiabilidad/DR, 1 observabilidad/medición, 1 enablement/documentación; rotación de guardias y revisión quincenal de demanda.

## OKRs y controles antimanipulación

**O1: entrega segura.** KR1: establecer en M2 un CFR observado verificable (cambios fallidos/cambios totales, ventana móvil 90 días), reducirlo a <15% en M12; el proxy inicial no cuenta como cumplimiento. KR2: elevar despliegues totales de 63/semana a >=126/semana sin aumento del número de Sev1 por ventana comparable, normalizando por volumen y severidad. KR3: evidencia SAST/SCA bloqueante para 100% de releases de tiers 0–2 antes de la auditoría trimestral siguiente (plan condicionado a fecha exacta). KR4: squads sin pipeline 2→0 en M6.

**O2: resiliencia.** KR1: RTO/RPO medidos por servicio crítico y simulacro trimestral. KR2: eliminar cambios manuales no aprobados en tier0 antes de M6. KR3: reducir MTTR medido con trazas de incidentes, objetivo de -30% sobre línea base instrumentada en M3 al cierre de M12.

Evitar *gaming*: no contar pipelines verdes sin despliegue real; no excluir rollbacks del CFR; conservar catálogo inmutable de cambios y Sev1 con clasificación revisada por equipos independientes; auditar muestras de incidentes y releases; publicar mediana y distribución además de promedio; medir frecuencia por servicio y no permitir fragmentar un deployment artificialmente; contrastar tickets, logs CI/CD y observabilidad; GRC revisa excepciones por fecha y propietario.

## Hitos de control

M1: taxonomía e instrumentación; M2: baseline observada. M3/M6/M9/M12: paquetes de evidencia, auditoría trimestral y simulacro DR. M3: piloto de política. M6: ambos equipos sin pipeline migrados. M9: despliegue progresivo en principales servicios. M12: reporte CIO con resultados, costes y riesgos residuales. La fecha exacta de auditoría se valida con GRC y se trabaja hacia atrás para cerrar evidencias antes de la revisión.
