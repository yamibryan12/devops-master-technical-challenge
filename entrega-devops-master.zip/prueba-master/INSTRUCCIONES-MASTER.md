# Master — 4 horas

Lee antes [`LEEME.md`](./LEEME.md) y [`PIPELINE-ESTANDAR.md`](./PIPELINE-ESTANDAR.md). Parte del [`starter/`](./starter/README.md) y de `starter/ejercicios/master/`. Se asume dominado el nivel Proficiente.
**Contexto:** banca digital con 12 squads (`starter/ejercicios/master/org-contexto.md`). Como referente técnico, el CIO te pide diagnóstico, resiliencia comprobada y gobierno de pipelines. Se evalúa **criterio e impacto organizacional**, no solo código.

| # | Tarea | Tiempo |
|---|-------|--------|
| 1 | Diagnóstico organizacional y roadmap de 12 meses | 45 min |
| 2 | Recuperación ante desastres (2 clústeres Minikube) | 60 min |
| 3 | Ingeniería del caos | 45 min |
| 4 | Detección de anomalías | 50 min |
| 5 | Gobierno de pipelines: política como código | 40 min |
| 6 | Sesión en vivo (60 min, con el evaluador) | — |

---

## Tarea 1 — Diagnóstico y roadmap (45 min)

**Haz:** analiza `ejercicios/master/org-teams.csv`, `org-incidents.csv` y `org-contexto.md` (con un script en `diagnostico/` que respalde tus números). Entrega `diagnostico/DIAGNOSTICO.md` (2–3 páginas).

**Espero ver:** brechas **con evidencia cuantitativa** (incluidas las que contradicen lo declarado por la organización), un roadmap a 12 meses **priorizado** (impacto/riesgo/esfuerzo, secuencia, **qué NO harás**), OKRs/KRs medibles con línea base y meta, fechas críticas (auditoría) y cómo evitas que las métricas se gamifiquen.

## Tarea 2 — Recuperación ante desastres (60 min)

**Haz:** `minikube start -p primary` y `minikube start -p dr`. Aplica `starter/k8s-base/postgres-dr.yaml` en `primary`, carga datos y programa un respaldo. Escribe `dr/failover.sh` (restaurar en `dr`) y **mide RPO y RTO reales** en `dr/drill-report.md`, comparándolos con los declarados (RTO 4 h, RPO 15 min). Añade 2 ADRs (`docs/adr/`): estrategia multi-región/multi-cloud y estrategia de datos/backups.

**Espero ver:** un drill **ejecutado** con cronómetro y datos reales (qué se perdió, cuánto tardó, qué fue manual), un análisis honesto de si los objetivos son alcanzables con esa arquitectura y qué cambiarías, y ADRs con alternativas descartadas.

## Tarea 3 — Ingeniería del caos (45 min)

**Haz:** en `chaos/` diseña y ejecuta **2 experimentos** sobre el servicio en Minikube (p. ej. matar pods, drenar un nodo, indisponibilizar una dependencia). Cada uno: hipótesis de estado estable basada en **SLO**, radio de explosión, **condición de aborto automática**, script y resultado. Corrige lo que descubras y **repite** un experimento. `chaos/hallazgos.md` incluye un plan de *game day*.

**Espero ver:** hipótesis medibles, guardrails que abortan solo, evidencia antes/después y al menos un hallazgo real corregido y reprobado.

## Tarea 4 — Detección de anomalías (50 min)

**Haz:** con `ejercicios/master/metrics_timeseries.csv` (7 días, 1 min: `traffic_rps, latency_p95_ms, error_rate, cpu_pct`) y `eventos.csv` (ventanas planificadas), escribe `anomaly/detect.py` y entrega `anomaly/anomalies.csv` (columna `timestamp` UTC ISO por cada minuto anómalo; opcional `metric`). `anomaly/METODO.md` (1 página).

**Espero ver:** un método justificado (estacionalidad, umbrales adaptativos o modelo) y **por qué supera a un umbral fijo**, manejo de falsos positivos (los eventos planificados no son anomalías), cómo evalúas sin etiquetas, cómo recalibras y cómo lo integras al flujo operativo. El evaluador puntúa tu CSV contra etiquetas ocultas; el método pesa tanto como el resultado.

## Tarea 5 — Gobierno de pipelines: política como código (40 min)

**Haz:** con los 5 workflows de squads en `ejercicios/master/org-workflows/` y el borrador `org-politica.md`, escribe `supply-chain/policy-check.py` (o `.sh`) que **audite workflows** contra la política por tier y **falle** (exit ≠ 0) ante violaciones bloqueantes. Soporta **excepciones con caducidad** (`exceptions.yml`: `owner`, `reason`, `expires`). Documenta en `supply-chain/tiers.md` las reglas por tier (qué bloquea, qué avisa) y un plan de adopción/migración de una página (incluye cómo moverías los squads de Jenkins).

**Espero ver:** detección correcta de las violaciones reales **sin falsos positivos** en el workflow sano, reglas como **datos** (no `if`s dispersos), resumen por squad/tier, excepciones que caducan, y un plan de adopción que no convierta a la plataforma en cuello de botella.

## Tarea 6 — Sesión en vivo (60 min) - (no considerar)

- **15 min:** presentación al CIO (qué encontraste, qué propones, costo, riesgos, qué decisión pides). Trae `docs/portfolio.md` con 3 enlaces verificables de tu impacto externo (charlas, artículos, OSS, formación, mentoría).
- **25 min:** simulacro de incidente Sev1 (escenario sorpresa; actuarás como Incident Commander).
- **20 min:** preguntas y defensa de tus decisiones.

---

## Entregable
Carpeta/repo con la estructura (`diagnostico/`, `dr/`, `chaos/`, `anomaly/`, `supply-chain/`, `docs/`) + `README.md` + `docs/evidencias/`. Postmortem del simulacro en las 24 h siguientes (1 página).
