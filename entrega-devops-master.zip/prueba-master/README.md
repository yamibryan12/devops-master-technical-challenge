# Prueba Técnica DevOps / DevSecOps / SRE — Master

## Entorno de ejecución

- Ubuntu WSL2
- Docker Desktop
- Kubernetes mediante Minikube
- Dos clusters: primary y dr
- Python 3
- PostgreSQL 16.3
- Bash y kubectl

## Tarea 1 — Diagnóstico organizacional

Archivos:
- diagnostico/analyze.py
- diagnostico/DIAGNOSTICO.md

Ejecución:
python3 diagnostico/analyze.py

El análisis utiliza los archivos CSV originales del repositorio.

## Tarea 2 — Disaster Recovery

Archivos:
- dr/backup.sh
- dr/failover.sh
- dr/drill-report.md
- docs/adr/001-estrategia-dr.md
- docs/adr/002-estrategia-backups.md

La implementación utiliza dos clusters Minikube
y PostgreSQL con almacenamiento persistente.

Generar respaldo:
./dr/backup.sh

Restaurar respaldo:
./dr/failover.sh RUTA_BACKUP NOMBRE_BASE

Resultados observados:
- Recuperación del ejercicio: 129 segundos.
- Antigüedad del respaldo: 259 segundos.
- Registros recuperados: 5 de 7.

Limitación: no se implementó conmutación completa
del tráfico de una aplicación (no exigida de forma explícita
por la tarea; véase el alcance del simulacro).

## Tarea 3 — Ingeniería del caos

Archivos:
- chaos/service.yaml
- chaos/setup.sh
- chaos/experiment-01.sh
- chaos/experiment-02.sh
- chaos/hallazgos.md

Preparación:
./chaos/setup.sh

Experimentos:
./chaos/experiment-01.sh before
./chaos/experiment-01.sh after
./chaos/experiment-02.sh

Las evidencias están en docs/evidencias/chaos/.

Resultados ejecutados: experimento 1 con 1 réplica 28/30 (FAIL frente a SLO 95 %); repetición con 2 réplicas 30/30 (PASS). Experimento 2: 0 réplicas detectadas, aborto activado y recuperación a 2/2 (PASS de guardrail operativo, no SLO HTTP). Consulte `chaos/hallazgos.md` para alcance y limitaciones.

## Tarea 4 — Detección de anomalías

Archivos:
- anomaly/detect.py
- anomaly/anomalies.csv
- anomaly/METODO.md

Ejecución:
python3 anomaly/detect.py

Datos procesados: 10080 minutos.
Anomalías identificadas: 531.

## Tarea 5 — Política como código

Archivos:
- supply-chain/policy-check.py
- supply-chain/policy.yml
- supply-chain/exceptions.yml
- supply-chain/tiers.md

Ejecución (requiere PyYAML en un entorno virtual):
python3 -m venv .venv
.venv/bin/pip install pyyaml
.venv/bin/python supply-chain/policy-check.py

El auditor detectó 21 incumplimientos.
Los bloqueos en workflows inseguros son intencionales. Tier 0 reporta ausencia de SCA como AVISO de transición: la plantilla sana `checkout` aún no lo contiene; no se presenta como enforcement implementado.

## Evidencias

Los registros de ejecución se encuentran en `docs/evidencias/`. Son logs de laboratorio local; no se han recreado resultados de ejecución fuera de ese entorno.

## Consideraciones

El entorno es local y utiliza recursos simulados.
Las decisiones arquitectónicas productivas se documentan
separadamente de las implementaciones realizadas.

## Validación adicional

`python3 supply-chain/test-policy.py` ejecuta pruebas de regresión del auditor sin alterar los workflows originales. `docs/postmortem-dr.md` documenta cronología, hallazgos y acciones del simulacro.
