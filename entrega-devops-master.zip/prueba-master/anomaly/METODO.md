# Detección de anomalías — método y operación

**Datos**: 10.080 minutos UTC, métricas de tráfico, p95, errores y CPU. Se parsean timestamps con zona UTC. Se excluyen de salida las ventanas cerradas de mantenimiento y despliegue indicadas en `eventos.csv` (bordes incluidos), porque son intervenciones previstas y no incidentes no planificados.

**Modelo**: para cada métrica y hora UTC del día (24 perfiles), mediana y desviación absoluta mediana escalada por 1,4826 (MAD), calculadas fuera de ventanas planificadas. Se usa un mínimo de dispersión por métrica para evitar división por cero. La regla detecta latencia, error_rate y CPU por encima de +5 MAD; para tráfico, magnitud absoluta >=6 MAD permite detectar caídas inesperadas y picos. Se exporta cada minuto marcado y las métricas responsables. Se consideran desviaciones frente al patrón horario, no un valor fijo global: picos de hora punta normales no disparan automáticamente incidentes. Umbrales son iniciales y deben ajustarse con operación real.

**Riesgos/falsos positivos**: la mediana por hora puede no capturar variaciones rápidas intrahorarias, feriados o tendencia semanal; una anomalía prolongada puede desplazar la línea base, por lo que es necesario usar ventanas de entrenamiento controladas. En producción se consolidarían alertas por episodio y por impacto, con histéresis (varios minutos consecutivos) y correlación de métricas para reducir ruido sin alterar el CSV de scoring por minuto.

**Sin etiquetas**: revisión manual de los 20 episodios de mayor puntuación, correlación con tickets/cambios, análisis de estabilidad en días sin intervenciones, sensibilidad a parámetros y proporción de alertas por hora. No atribuir precision/recall sin ground truth. Luego de obtener etiquetas confirmadas, medir precisión, recall y tiempo hasta detectar y ajustar umbrales con equipo SRE.

**Recalibración**: recomputar cada semana con 4–8 semanas de datos etiquetados como sanos, excluyendo incidentes conocidos y mantenimientos; vigilar deriva estacional y evitar que incidentes contaminen la línea base. **Operación**: job programado de detección, salida a alertmanager/SIEM, trazabilidad al change y runbooks; alertas críticas requieren combinación de impacto (errores/p95) y saturación, con on-call y retroalimentación post-incidente.

Ejecución: `python3 anomaly/detect.py`. Solo librería estándar de Python.
