#!/usr/bin/env python3
"""Estacionalidad por hora UTC, mediana/MAD robusta y supresión de eventos planificados. Sin paquetes externos."""
import csv,statistics,collections,pathlib,datetime,math
ROOT=pathlib.Path(__file__).resolve().parents[1]
SRC=ROOT/'starter/ejercicios/master'; OUTPUT=ROOT/'anomaly/anomalies.csv'
def dt(x):return datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
with (SRC/'metrics_timeseries.csv').open() as f: rows=list(csv.DictReader(f))
with (SRC/'eventos.csv').open() as f: events=[(dt(e['start']),dt(e['end'])) for e in csv.DictReader(f)]
cols=['traffic_rps','latency_p95_ms','error_rate','cpu_pct']
for r in rows:
 r['date']=dt(r['timestamp']);r['hour']=r['date'].hour
 for k in cols:r[k]=float(r[k])
# Hora del día: suficientemente muestras (7*60) y robustece frente a picos.
stats={}
for k in cols:
 for h in range(24):
  a=[r[k] for r in rows if r['hour']==h and not any(s<=r['date']<=e for s,e in events)]
  med=statistics.median(a);mad=statistics.median(abs(x-med) for x in a)
  stats[k,h]=(med,max(1.4826*mad, {'traffic_rps':12,'latency_p95_ms':6,'error_rate':0.07,'cpu_pct':5}[k]))
marked=[]
for r in rows:
 if any(s<=r['date']<=e for s,e in events):continue
 scores={k:(r[k]-stats[k,r['hour']][0])/stats[k,r['hour']][1] for k in cols}
 # Latencia, errores, CPU elevados; tráfico puede subir o caer, pero requiere señal sólida.
 bad=[k for k in ('latency_p95_ms','error_rate','cpu_pct') if scores[k]>=5]
 if abs(scores['traffic_rps'])>=6:bad.append('traffic_rps')
 if bad:marked.append((r['timestamp'],','.join(bad)))
OUTPUT.parent.mkdir(parents=True,exist_ok=True)
with OUTPUT.open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['timestamp','metric']);w.writerows(marked)
print(f'Analizados {len(rows)} minutos; anomalías {len(marked)}; salida {OUTPUT}')
