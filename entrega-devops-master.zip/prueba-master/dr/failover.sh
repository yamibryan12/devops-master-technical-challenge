#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$ROOT/backups"
REPORT_DIR="$ROOT/../docs/evidencias/dr"

CLUSTER="dr"
NAMESPACE="data"
POD="postgres-0"
DB_USER="postgres"

BACKUP_FILE="${1:-$BACKUP_DIR/latest.dump}"
TARGET_DB="${2:-recovery_$(date -u +%Y%m%d%H%M%S)}"

# Identifier protection: never interpolate an arbitrary database name into SQL.
if [[ ! "$TARGET_DB" =~ ^[a-z][a-z0-9_]{0,62}$ ]]; then
  echo "[ERROR] Nombre de base no permitido: $TARGET_DB" >&2
  exit 2
fi

mkdir -p "$REPORT_DIR"

BACKUP_FILE="$(readlink -f "$BACKUP_FILE")"

# Fail closed if the backup path points outside the local backup repository.
case "$BACKUP_FILE" in
  "$BACKUP_DIR"/*) ;;
  *) echo "[ERROR] El archivo debe estar en dr/backups/" >&2; exit 2 ;;
esac
REPORT_FILE="$REPORT_DIR/failover-$(date -u +%Y%m%dT%H%M%SZ).log"

START_TIME=$(date +%s)

exec > >(tee -a "$REPORT_FILE") 2>&1

echo "[INFO] Inicio UTC: $(date -u -Is)"
echo "[INFO] Cluster destino: $CLUSTER"
echo "[INFO] Backup seleccionado: $BACKUP_FILE"
echo "[INFO] Base de recuperación: $TARGET_DB"

if [[ ! -s "$BACKUP_FILE" ]]; then
  echo "[ERROR] El respaldo no existe o está vacío."
  exit 1
fi

# Validación de integridad
if [[ ! -f "$BACKUP_FILE.sha256" ]]; then
  echo "[ERROR] No se encontró el hash SHA256."
  exit 1
fi

(
  cd "$(dirname "$BACKUP_FILE")"
  sha256sum -c "$(basename "$BACKUP_FILE").sha256"
)

# Verificar destino
kubectl --context="$CLUSTER" -n "$NAMESPACE" \
  exec "$POD" -- pg_isready -U "$DB_USER"

# Evitar sobrescritura
EXISTS=$(
  kubectl --context="$CLUSTER" -n "$NAMESPACE" \
    exec "$POD" -- \
    psql -U "$DB_USER" -d postgres -Atqc \
    "SELECT 1 FROM pg_database WHERE datname='$TARGET_DB'"
)

if [[ "$EXISTS" == "1" ]]; then
  echo "[ERROR] La base $TARGET_DB ya existe."
  exit 1
fi

echo "[INFO] Creando base de recuperación"

kubectl --context="$CLUSTER" -n "$NAMESPACE" \
  exec "$POD" -- createdb -U "$DB_USER" "$TARGET_DB"

echo "[INFO] Restaurando respaldo"

kubectl --context="$CLUSTER" -n "$NAMESPACE" \
  exec -i "$POD" -- \
  pg_restore \
    -U "$DB_USER" \
    -d "$TARGET_DB" \
    --no-owner \
    --no-acl \
    --exit-on-error \
    < "$BACKUP_FILE"

echo "[INFO] Validando registros"

COUNT=$(
  kubectl --context="$CLUSTER" -n "$NAMESPACE" \
    exec "$POD" -- \
    psql -U "$DB_USER" -d "$TARGET_DB" -Atqc \
    "SELECT COUNT(*) FROM transacciones"
)

END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

if [[ ! "$COUNT" =~ ^[0-9]+$ ]] || (( COUNT < 1 )); then
  echo "[ERROR] La restauración no contiene registros verificables"
  exit 1
fi
echo "[RESULTADO] Registros restaurados: $COUNT"
echo "[RESULTADO] Duración: ${DURATION} segundos"
echo "[RESULTADO] Fin UTC: $(date -u -Is)"
echo "[OK] Restauración completada"
echo "[AVISO] No se realizó conmutación de tráfico."
echo "[AVISO] La promoción requiere verificar fencing del origen."
