# Disaster Recovery Drill Report

## 1. Objetivo

Validar la capacidad de recuperación de PostgreSQL entre
dos clusters Kubernetes locales mediante respaldos lógicos.

Objetivos de referencia:

- RTO: 4 horas.
- RPO: 15 minutos.

## 2. Arquitectura evaluada

Se utilizaron dos clusters Minikube independientes:

- primary: PostgreSQL principal.
- dr: PostgreSQL de recuperación.

Ambos clusters utilizan Docker Desktop como infraestructura
subyacente y están alojados en el mismo equipo físico.

PostgreSQL utiliza StatefulSet y PersistentVolumeClaim.

El mecanismo de respaldo implementado utiliza pg_dump
en formato CUSTOM y validación mediante pg_restore -l.

Los respaldos se almacenan en Ubuntu WSL2.

## 3. Procedimiento ejecutado

1. Despliegue de PostgreSQL en primary.
2. Creación de cinco transacciones.
3. Generación de respaldo lógico.
4. Inserción de dos transacciones adicionales.
5. Registro del estado previo al incidente.
6. Simulación de indisponibilidad de PostgreSQL.
7. Restauración del último respaldo en dr.
8. Verificación de integridad y cantidad de registros.
9. Reactivación del servicio principal.

## 4. Resultados observados

| Indicador | Objetivo | Observado |
|---|---|---|
| Tiempo del ejercicio | 4 horas | 129 segundos |
| Antigüedad del backup | 15 minutos | 259 segundos |
| Registros antes del fallo | N/A | 7 |
| Registros restaurados | N/A | 5 |
| Registros ausentes del backup | N/A | 2 |

Último backup utilizado:
2026-10-22T00:11:50Z

Inicio registrado del incidente:
2026-10-22T00:16:09Z

La restauración se realizó satisfactoriamente.

La antigüedad del respaldo fue de 259 segundos,
equivalentes a 4 minutos y 19 segundos.

El tiempo observado del procedimiento fue de
129 segundos, equivalentes a 2 minutos y 9 segundos.

## 5. Limitaciones

El ejercicio simuló la indisponibilidad de PostgreSQL,
no la caída completa de una región cloud.

No se implementó una conmutación automática del tráfico
de una aplicación hacia el cluster de recuperación.

Por este motivo, el tiempo observado no representa
un RTO extremo a extremo de una aplicación productiva.

La antigüedad del backup es una aproximación temporal
del punto de recuperación y no constituye un RPO
certificado.

Dos transacciones realizadas después del respaldo
no estaban presentes en los datos restaurados.

Los clusters comparten la misma infraestructura física,
por lo que no existe independencia frente a fallos
del equipo anfitrión.

## 6. Automatización de backups

Se implementó backup.sh para generar respaldos lógicos
con nombres basados en timestamps UTC.

El script genera hashes SHA-256 para verificar integridad.

Cron ejecuta el respaldo cada 15 minutos y utiliza
flock para reducir el riesgo de ejecuciones concurrentes.

Se verificó una ejecución automática exitosa el
2026-10-22T00:30:01Z.

## 7. Recomendaciones

- Implementar almacenamiento externo para respaldos.
- Configurar monitoreo y alertas de backups fallidos.
- Definir política de retención.
- Ejecutar pruebas periódicas de restauración.
- Implementar conmutación controlada del servicio.
- Incorporar controles para evitar split-brain.
- Evaluar replicación y recuperación continua mediante WAL.
- Validar RTO y RPO extremo a extremo.

## 8. Conclusión

El simulacro validó la restauración de PostgreSQL
entre dos clusters locales de Kubernetes.

La recuperación de los cinco registros respaldados
fue satisfactoria.

La solución constituye una prueba funcional de
restauración y continuidad operativa, pero todavía
no representa una estrategia DR productiva completa.


## Alcance frente a INSTRUCCIONES-MASTER.md

El requisito práctico de esta tarea es **restaurar la base en `dr`**, medir la ventana de recuperación y documentar pérdidas, operaciones manuales y límites. El ejercicio ejecutado cubre restauración en `dr`, con medición de **129 segundos** desde la marca de inicio del incidente hasta la verificación de los registros. La antigüedad de respaldo medida fue **259 segundos**. La interrupción simulada afectó a PostgreSQL, no al clúster completo.

La restauración tardó menos que el RTO objetivo y la antigüedad medida fue menor que los 15 minutos objetivo, **solo para este incidente controlado**. No se infiere de ello una garantía de RTO/RPO en producción. El archivo restaurado dejó fuera dos transacciones posteriores al respaldo. La reactivación de `primary`, así como la selección y consulta de la base en `dr`, se realizaron manualmente. Un failover transparente de aplicaciones no formó parte del experimento ejecutado.

Para uso real: programar un ensayo que incluya descubrimiento del incidente, fencing del origen, redirección de clientes y pruebas transaccionales; medir desde el primer impacto al usuario hasta la recuperación confirmada.
