#!/usr/bin/env bash
set -Eeuo pipefail

CLUSTER="primary"
NAMESPACE="data"
POD="postgres-0"
DB="postgres"
USER_DB="postgres"

BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)/backups"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_FILE="$BACKUP_DIR/postgres-$TIMESTAMP.dump"
TEMP_FILE="$BACKUP_FILE.tmp"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
umask 077

trap 'rm -f "$TEMP_FILE"' EXIT

echo "[INFO] Iniciando backup: $(date -u -Is)"

kubectl --context="$CLUSTER" -n "$NAMESPACE" \
  exec "$POD" -- \
  pg_dump -U "$USER_DB" -d "$DB" -Fc \
  > "$TEMP_FILE"

test -s "$TEMP_FILE"

docker run --rm \
  -v "$BACKUP_DIR:/backups:ro" \
  postgres:16.3-alpine \
  pg_restore -l "/backups/$(basename "$TEMP_FILE")" \
  > /dev/null

mv "$TEMP_FILE" "$BACKUP_FILE"

sha256sum "$BACKUP_FILE" > "$BACKUP_FILE.sha256"

ln -sfn "$(basename "$BACKUP_FILE")" \
  "$BACKUP_DIR/latest.dump"

echo "[OK] Backup completado:"
echo "$BACKUP_FILE"
echo "[INFO] SHA256:"
cat "$BACKUP_FILE.sha256"
