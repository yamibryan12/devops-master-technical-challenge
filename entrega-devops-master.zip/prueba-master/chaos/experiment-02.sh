#!/usr/bin/env bash
set -Eeuo pipefail

NS="chaos-lab"
CTX="primary"
OUT="docs/evidencias/chaos/experiment-02.log"

mkdir -p "$(dirname "$OUT")"
exec > >(tee "$OUT") 2>&1

restore() {
  echo "[INFO] Restaurando servicio"
  kubectl --context="$CTX" -n "$NS" \
    scale deployment/web --replicas=2

  kubectl --context="$CTX" -n "$NS" \
    rollout status deployment/web --timeout=90s
}

trap restore EXIT

echo "[INFO] Verificando estado inicial"

kubectl --context="$CTX" -n "$NS" \
  rollout status deployment/web --timeout=60s

echo "[INFO] Inyectando fallo controlado"

kubectl --context="$CTX" -n "$NS" \
  scale deployment/web --replicas=0

kubectl --context="$CTX" -n "$NS" \
  wait --for=delete pod -l app=web --timeout=60s

echo "[INFO] Verificando indisponibilidad"

READY=$(kubectl --context="$CTX" -n "$NS" \
  get deployment web \
  -o jsonpath='{.status.readyReplicas}')

READY=${READY:-0}

echo "Ready replicas: $READY"

if [[ "$READY" == "0" ]]; then
  echo "[ABORT] Servicio sin replicas disponibles"
  echo "[PASS] Fallo detectado correctamente"
else
  echo "[FAIL] No se detecto indisponibilidad"
  exit 1
fi
