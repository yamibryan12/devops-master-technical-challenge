#!/usr/bin/env bash
# Uso: ./chaos/experiment-01.sh before|after
set -Eeuo pipefail
MODE="${1:?before o after}"
[[ "$MODE" == before || "$MODE" == after ]] || exit 2
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/docs/evidencias/chaos/experiment-01-$MODE.log"
mkdir -p "$(dirname "$OUT")"
exec > >(tee "$OUT") 2>&1
NS=chaos-lab
replicas=1
[[ "$MODE" == after ]] && replicas=2
kubectl --context=primary -n "$NS" scale deploy/web --replicas="$replicas"
kubectl --context=primary -n "$NS" rollout status deploy/web --timeout=180s
kubectl --context=primary -n "$NS" get pods -l app=web -o wide
kubectl --context=primary proxy --port=18081 >/tmp/chaos-proxy-01.log 2>&1 &
PROXY_PID=$!
restore(){ kill "$PROXY_PID" 2>/dev/null || true; kubectl --context=primary -n "$NS" scale deploy/web --replicas=2 >/dev/null 2>&1 || true; }
trap restore EXIT
URL='http://127.0.0.1:18081/api/v1/namespaces/chaos-lab/services/http:web:80/proxy/'
sleep 2
curl --max-time 4 -fsS "$URL" >/dev/null || { echo 'Error: baseline sin servicio';exit 1; }
POD="$(kubectl --context=primary -n "$NS" get pods -l app=web -o jsonpath='{.items[0].metadata.name}')"
echo "Hypothesis: éxito HTTP >=95% durante 30 probes, y abortar con 3 fallos consecutivos"
echo "Blast radius: deployment web del namespace chaos-lab; modo=$MODE; réplicas=$replicas; pod eliminado=$POD"
kubectl --context=primary -n "$NS" delete pod "$POD" --wait=false
ok=0; fail=0; consecutive=0; aborted=0
for n in $(seq 1 30); do
 if curl --connect-timeout 1 --max-time 2 -fsS "$URL" >/dev/null 2>&1;then
  ok=$((ok+1));consecutive=0
 else
  fail=$((fail+1));consecutive=$((consecutive+1))
 fi
 echo "probe=$n ok=$ok fail=$fail streak=$consecutive"
 if (( consecutive>=3 ));then aborted=1;echo '[ABORT] Tres fallos consecutivos. Se restaura replicas=2';break;fi
 sleep 1
done
count=$((ok+fail))
echo "RESULT success=${ok}/${count}, failures=${fail}, aborted=${aborted}"
kubectl --context=primary -n "$NS" get pods -l app=web
if ((aborted));then exit 3;fi
if ((ok*100<count*95));then echo '[FAIL] SLO 95%';exit 4;fi
echo '[PASS] SLO de disponibilidad experimental'
