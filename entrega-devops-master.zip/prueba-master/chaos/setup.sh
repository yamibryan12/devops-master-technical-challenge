#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/docs/evidencias/chaos"
kubectl --context=primary apply -f "$ROOT/chaos/service.yaml"
kubectl --context=primary -n chaos-lab rollout status deploy/web --timeout=180s
kubectl --context=primary -n chaos-lab get deploy,pods,svc | tee "$ROOT/docs/evidencias/chaos/setup.txt"
echo 'Servicio listo. Los experimentos arrancan el proxy temporal ellos mismos.'
