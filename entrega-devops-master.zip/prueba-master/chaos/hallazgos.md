# Ingeniería del caos — resultados y game day

## Alcance y guardrails

Pruebas en Minikube `primary`, exclusivamente en el namespace `chaos-lab`, con un servicio HTTP de laboratorio. PostgreSQL (`data`) y el clúster `dr` quedaron fuera del radio de explosión. No se usó la aplicación Java original; las conclusiones se limitan al servicio de prueba. Se conservaron los registros de ejecución en `docs/evidencias/chaos/`.

## Experimento 1 — eliminación de pod

**Hipótesis:** al eliminar un pod con una única réplica, la disponibilidad HTTP durante 30 solicitudes estará por debajo del SLO experimental del 95 %. Con dos réplicas se espera cumplirlo. **Radio:** `deployment/web` en `chaos-lab`. **Guardrail:** abortar ante tres errores consecutivos, restaurar dos réplicas y registrar el resultado; además se limita la duración con timeout al ejecutarlo.

| Fase | Solicitudes correctas | Disponibilidad | SLO (95 %) | Resultado |
|---|---:|---:|---|---|
| Antes, una réplica | 28/30 | 93,33 % | No cumple | FAIL |
| Después, dos réplicas | 30/30 | 100 % | Cumple | PASS |

**Hallazgo y corrección:** la dependencia de un único pod produjo dos solicitudes fallidas. Se incrementó el número de réplicas a dos y se repitió el mismo escenario. La nueva muestra no tuvo errores. Esto es una mejora observada en el laboratorio, no prueba estadística de disponibilidad permanente. Evidencia: `experiment-01-before.log` y `experiment-01-after.log`.

## Experimento 2 — indisponibilidad controlada del Deployment

**Hipótesis:** al llevar deliberadamente `deployment/web` a cero réplicas, Kubernetes indicará cero réplicas listas y el procedimiento de aborto restaurará las dos réplicas, sin afectar otros namespaces. **Radio:** solo `web` en `chaos-lab`. **Condición de aborto:** al constatar cero réplicas listas se termina la inyección y un `trap EXIT` ejecuta la restauración; no se trata de un guardrail preventivo basado en latencia HTTP.

**Resultado ejecutado:** los pods fueron eliminados, `Ready replicas: 0`, el script registró `[ABORT]` y `[PASS]`, y el Deployment volvió a `2/2`. Evidencia: `experiment-02.log` y comprobación de `kubectl get deployment web`. La palabra PASS confirma detección y restauración del estado del Deployment, **no** el cumplimiento de un SLO HTTP durante la caída.

**Iteración descartada:** inicialmente se probó una readiness probe con ruta `/notfound`. Las 40 solicitudes observadas terminaron sin errores, por lo que esa hipótesis no se demostró. Es compatible con que el rollout preservara endpoints antiguos. Se sustituyó por la interrupción explícita descrita arriba. Para una siguiente iteración mediríamos EndpointSlices, solicitudes HTTP y tiempo de recuperación conjuntamente; la observación anterior no debe presentarse como una caída demostrada.

## Plan de game day

| Momento | Responsable | Acción y evidencia |
|---|---|---|
| T-30 min | Incident Commander + dueño del servicio | Autorizar ventana, comprobar 2/2 pods y acordar SLO y límites |
| T0 | Operador SRE | Iniciar una única inyección en `chaos-lab`, registrar inicio |
| T+1 a T+3 | Observador | Registrar HTTP, réplicas y endpoints; vigilar condición de aborto |
| Al disparar el límite | Operador SRE | Detener el experimento y restaurar estado previo |
| T+5 | Dueño del servicio | Verificar 2/2 réplicas y peticiones HTTP exitosas |
| T+20 | Incident Commander | Registrar hallazgo, causa probable, responsable y siguiente medida |

**Riesgos pendientes:** no se ha validado un fallo de dependencia de la aplicación real ni un rollback automatizado ante degradación de latencia/error_rate. El experimento 2 comprueba el estado del Deployment, no un SLO de usuario final. No trasladar este ensayo a producción sin permisos, métricas y salvaguardas adicionales.
