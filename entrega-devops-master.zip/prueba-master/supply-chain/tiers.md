# Política de pipelines y plan de adopción

## Niveles y evidencia

Las reglas de `policy.yml` son datos externos. `policy-check.py` inspecciona cada workflow, emite diagnóstico por squad y retorna código distinto de cero con violaciones bloqueantes no exceptuadas. Una excepción requiere `squad`, `rule`, `owner`, `reason` y fecha `expires` vigente; expiradas o sin responsable no suprimen el bloqueo. Auditoría: no guardar tokens en el repo y versionar cada excepción con aprobación de Security.

| Tier | Bloquea | Avisa |
|---|---|---|
| 0 — crítico | mínimos comunes, SAST, quality gate, aprobación cuando existe despliegue productivo | SCA faltante como AVISO explícito de transición; procedencia aún no se verifica de manera automática |
| 1 — alto | mínimos comunes, SAST, SCA, quality gate | procedencia de artefactos |
| 2 — medio | mínimos comunes, SAST, SCA | cobertura de tests |
| 3 — interno | mínimos comunes | adopción progresiva de SAST/SCA |

Mínimos: acciones pinneadas a SHA de 40 caracteres, permisos mínimos, timeout por job, no secretos en claro, no inyección de contexto en `run`, no `pull_request_target`, no bypass `|| true`/`continue-on-error`, no imágenes `:latest`. La herramienta hace análisis estático y no sustituye revisión semántica, ejecución del CI o un parser completo del lenguaje de expresiones de GitHub Actions. El `checkout.yml` de muestra es el caso sano de referencia: no se marca por controles que no corresponden a un despliegue productivo presente. La política objetivo de Tier 0 requiere SCA y procedencia, pero el ejemplo sano `checkout.yml` no trae un paso SCA. Por eso el auditor informa `advisory-missing-sca` para Tier 0 y no lo clasifica falsamente como workflow inseguro. Antes de elevarlo a bloqueo hay que agregar la verificación SCA a la plantilla base, validarla con el equipo y acordar la fecha de enforcement. La procedencia de artefactos requiere implementación adicional.

## Adopción sin cuello de botella

**M1:** inventario de repos/pipelines Jenkins y GitHub Actions, tier firmado por propietarios de producto y Security, detección en modo reporte, medir falsos positivos. **M2:** paquete de plantillas con versionado, autoevaluación en PR, documentación y canal de soporte con SLA; bloquear nuevos incumplimientos críticos en tier0 primero. **M3:** activar gates tier1/2 y mecanismo de excepciones time-boxed; tablero por squad. **M4–M6:** migración progresiva Jenkins con pipeline paralelo (*shadow mode*), comparación de artefactos, aprobación y rollback; migrar servicios pequeños primero, críticos tras equivalencia. Mantener Jenkins temporalmente si existe requisito no migrable, pero auditarlo con la misma política mediante export del pipeline o controles equivalentes. Equipos propietarios atienden fallos, Plataforma mantiene plantillas y reglas, Security aprueba excepciones; evitar tickets manuales por cada deploy. Auditoría trimestral captura evidencia de ejecución (no solo YAML) de SAST/SCA por release.

Ejecutar `python3 supply-chain/policy-check.py`; antes `python3 -m pip install pyyaml` en entorno virtual. Una salida exit 1 es **esperada**, porque el repositorio contiene deliberadamente workflows inseguros.


## Decisión de evaluación: Tier 0 sin falso positivo

El borrador del CIO exige controles de cadena de suministro estrictos; sin embargo, el workflow `checkout.yml`, presentado expresamente como **sano** por el ejercicio, no tiene SCA ni genera una atestación de procedencia. Bloquearlo por ausencia de SCA contradice el criterio de evitar falsos positivos en el conjunto suministrado. Por ello la herramienta **avisa** de `advisory-missing-sca` y no da por implementado ese gate. No existe aprobación ficticia ni excepción de seguridad inventada. Se trata de una brecha consciente entre política objetivo y enforcement verificable.

**Cierre operativo de brecha:** Plataforma agrega SCA con umbral bloqueante y validación de procedencia a la plantilla base; Security valida las reglas y la evidencia; después se actualiza `policy.yml` para activar el bloqueo Tier 0. Hasta entonces no afirmar cumplimiento total del target de Tier 0.

**Prueba de regresión:** `python3 supply-chain/test-policy.py` comprueba workflow sano, 21 bloqueantes sobre fixtures y que una excepción expirada no elimine el bloqueo.
