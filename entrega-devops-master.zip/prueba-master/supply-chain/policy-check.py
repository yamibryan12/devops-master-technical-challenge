#!/usr/bin/env python3
import pathlib,re,sys,datetime,collections
try:import yaml
except ImportError:sys.exit('Instalar dependencia: python3 -m pip install pyyaml (en venv)')
root=pathlib.Path(__file__).resolve().parents[1]
conf=yaml.safe_load((root/'supply-chain/policy.yml').read_text())
exceptions=yaml.safe_load((root/'supply-chain/exceptions.yml').read_text()) or {}
exceptions=exceptions.get('exceptions',[])
def waived(team,rule):
 for ex in exceptions:
  if ex.get('squad')!=team or ex.get('rule')!=rule:continue
  if not all(ex.get(k) for k in ('owner','reason','expires')):continue
  try:
   if datetime.date.fromisoformat(str(ex['expires']))>=datetime.date.today():return True
  except ValueError:pass
 return False
violations=0
for file in sorted((root/'starter/ejercicios/master/org-workflows').glob('*.yml')):
 team=file.stem; tier=conf['assignments'].get(team,'tier3'); policy=conf['tiers'][tier]
 src=file.read_text(); doc=yaml.safe_load(src) or {}; jobs=doc.get('jobs',{}) or {}; steps=[s for j in jobs.values() for s in j.get('steps',[])]
 issues=[]
 def fail(rule):
  if not waived(team,rule):issues.append(rule)
 trigger=doc.get('on',doc.get(True,{}))
 if 'pull_request_target' in str(trigger):fail('pull_request_target')
 perms=doc.get('permissions',{})
 if perms=='write-all' or not perms or (isinstance(perms,dict) and any(v=='write' for v in perms.values())):fail('permissions')
 if re.search(r'(?im)^\s*(?:[A-Z][A-Z_]*(?:PASSWORD|SECRET|TOKEN|KEY))\s*:\s*(?!["\x27]?\$\{\{)(?!["\x27]?\s*$)[^#\n]+',src):fail('plaintext-secret')
 if re.search(r'\$\{\{\s*github\.(?:event\.|head_ref|ref_name)',src) and re.search(r'(?s)run\s*:',src):
  # env indirection is acceptable; detect expressions physically in run blocks only.
  if re.search(r'(?m)^\s*(?:-|\s*)?run:\s*[^\n]*\$\{\{\s*github\.(?:event\.|head_ref|ref_name)',src) or re.search(r'(?m)^\s+echo\s+.*\$\{\{\s*github\.(?:event\.|head_ref|ref_name)',src):fail('context-injection')
 for job in jobs.values():
  if not job.get('timeout-minutes'):fail('job-timeout')
 for s in steps:
  if 'uses' in s and not re.search(r'@[0-9a-f]{40}$',str(s['uses'])):fail('unpinned-action')
  command=str(s.get('run',''))
  if re.search(r'\|\|\s*true\b',command) or s.get('continue-on-error') is True:fail('bypass-gate')
  if re.search(r'docker\s+build\b[^\n]*:(?:latest|main)\b',command):fail('mutable-image')
  if 'checkmarx-mock' in command and '--fail-on' not in command:fail('sca-without-gate')
  if 'fortify-mock' in command and '--fail-on' not in command:fail('sast-without-gate')
  if 'sonar-scanner-mock' in command and '--gate' not in command:fail('quality-without-gate')
 commands='\n'.join(str(s.get('run','')) for s in steps)
 if policy.get('require_sast') and not re.search(r'fortify-mock|checkmarx-mock\s+--engine\s+sast',commands):
  # checkout has fortify; catalog has Sonar (quality) and SCA but lacks explicit SAST
  fail('missing-sast')
 if policy.get('require_sca') and not re.search(r'checkmarx-mock\s+--engine\s+sca|jfrog-mock',commands):fail('missing-sca')
 if policy.get('require_quality') and not re.search(r'sonar-scanner-mock\b[^\n]*--gate\b',commands):fail('missing-quality-gate')
 # No release to production in checkout sample; approval only required for actual prod deployment
 if policy.get('approval') and re.search(r'kubectl\s+apply|helm\s+upgrade|deploy.*prod',commands,re.I):
  if not any(j.get('environment') for j in jobs.values()):fail('missing-environment-approval')
 unique=list(dict.fromkeys(issues));violations+=len(unique)
 advisories=[]
 if policy.get('advise_sca') and not re.search(r'checkmarx-mock\s+--engine\s+sca|jfrog-mock',commands):
  advisories.append('advisory-missing-sca')
 print(f'{team:15} {tier:6} {"PASS" if not unique else "FAIL"} {", ".join(unique)}' + (f' [AVISOS: {", ".join(advisories)}]' if advisories else ''))
print(f'Bloqueantes totales: {violations}')
sys.exit(1 if violations else 0)
