#!/usr/bin/env python3
"""Pruebas de regresión del auditor: workflow sano, incidentes y excepción caducada."""
import pathlib, shutil, subprocess, sys, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="policy-regression-") as d:
    tmp = pathlib.Path(d) / "repo"
    (tmp / "supply-chain").mkdir(parents=True)
    (tmp / "starter/ejercicios/master/org-workflows").mkdir(parents=True)
    for f in ("policy.yml", "exceptions.yml", "policy-check.py"):
        shutil.copy2(ROOT / "supply-chain" / f, tmp / "supply-chain" / f)
    src = ROOT / "starter/ejercicios/master/org-workflows"
    for wf in src.glob("*.yml"):
        shutil.copy2(wf, tmp / "starter/ejercicios/master/org-workflows" / wf.name)
    def run():
        return subprocess.run([sys.executable, str(tmp / "supply-chain/policy-check.py")], capture_output=True, text=True)
    result = run()
    assert result.returncode == 1, result.stdout + result.stderr
    assert "checkout" in result.stdout and "checkout        tier0  PASS" in result.stdout, result.stdout
    assert "Bloqueantes totales: 21" in result.stdout, result.stdout
    # A expired waiver for ledger's permissions may not suppress its violation.
    with (tmp / "supply-chain/exceptions.yml").open("w") as o:
        o.write("exceptions:\n  - squad: ledger\n    rule: permissions\n    owner: security\n    reason: test-expired\n    expires: '2020-01-01'\n")
    expired = run()
    assert expired.returncode == 1 and "permissions" in next(line for line in expired.stdout.splitlines() if line.startswith('ledger')), expired.stdout
    print("PASS: checkout sano, violaciones intencionales y excepción expirada")
