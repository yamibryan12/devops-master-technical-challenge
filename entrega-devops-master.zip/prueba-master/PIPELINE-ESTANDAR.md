# Estándar de pipelines GitHub Actions (qué esperamos ver)

> Todo se valida **en local** con `act` (`starter/tools/act-run.sh`). Lo que `act` no puede ejecutar (aprobaciones de `environment`, OIDC, `attest`, push a GHCR)
> se escribe correctamente y se protege con `if: ${{ !env.ACT }}` para que el resto corra en local; el evaluador lo revisa leyendo el YAML.

Aplica a todos los workflows, acciones compuestas y reutilizables que entregues. Tu evaluador revisa estos puntos
(en parte con herramientas automáticas). Si decides **no** cumplir uno, justifícalo por escrito en tu README.

## 1. Seguridad
- [ ] `permissions:` **mínimos** a nivel de workflow (`contents: read`) y elevados **solo por job** que lo necesite (`packages: write`, `id-token: write`…).
- [ ] Acciones de **terceros fijadas por SHA de commit** (40 hex) con comentario de versión; `actions/*` al menos por versión exacta. Nada de `@main` / `@latest`.
- [ ] **Sin secretos en claro** ni `echo` de secretos. Los secretos entran por `env:` desde `secrets.*` solo en el step que los usa.
- [ ] **Sin inyección de scripts**: contexto no confiable (`github.event.pull_request.title`, `github.head_ref`, …) se pasa por `env:`, nunca interpolado dentro de `run:`.
- [ ] No usar `pull_request_target` salvo justificación excepcional (y nunca haciendo checkout del código del PR).
- [ ] `actions/checkout` con `persist-credentials: false`.
- [ ] Autenticación a nube vía **OIDC** (federated credentials), no con secretos de larga vida.
- [ ] Imágenes con **tag inmutable** (SHA/versión), nunca `:latest`; contenedor **no-root**.

## 2. Confiabilidad y costo
- [ ] `timeout-minutes` en **todos** los jobs.
- [ ] `concurrency` (cancela runs obsoletos en PR; **no** canceles despliegues a producción en curso).
- [ ] Disparadores acotados: `branches`, `paths`/`paths-ignore`; `workflow_dispatch` para ejecución manual.
- [ ] Caché de dependencias (Maven/npm) y de capas Docker.
- [ ] `defaults.run.shell: bash` y scripts con `set -euo pipefail`.
- [ ] Artifacts con `retention-days` explícito; reportes se suben incluso si el job falla (`if: ${{ !cancelled() }}`).

## 3. Calidad del diseño
- [ ] Etapas con `needs:` y condiciones `if:` claras: ningún despliegue se ejecuta si fallan pruebas o gates.
- [ ] **Construir una vez, promover el mismo artefacto** (por digest/SHA) entre entornos.
- [ ] Despliegues con `environment:` (aprobaciones requeridas y secretos por entorno).
- [ ] Reutilización: workflows reutilizables (`workflow_call`) y/o acciones compuestas en vez de copiar/pegar (desde Competente).
- [ ] Nombres claros de jobs/steps, outputs explícitos, sin lógica duplicada.
- [ ] Resumen en `$GITHUB_STEP_SUMMARY` cuando aporte (resultados de gates, métricas).

## 4. Gates de seguridad / calidad (mocks)
- [ ] Cada herramienta mock se invoca con **reglas explícitas** (`--fail-on`, `--gate`, `--sla`) y justificadas (comentario o doc).
- [ ] Los gates **bloquean** (sin `continue-on-error`, sin `|| true`).
- [ ] Reglas **diferenciadas** por contexto cuando el nivel lo pide (PR vs main vs producción; servicio crítico vs no crítico).
- [ ] Evidencia de que fallan con `MOCK_SCENARIO=dirty`.
- [ ] Reportes (`--report`) publicados como artifact.

## 5. Repositorio
- [ ] `CODEOWNERS`, plantilla de PR, `dependabot.yml` (ecosistema `github-actions` + dependencias del proyecto).
- [ ] Protección de rama documentada (revisiones requeridas, checks requeridos, sin force-push).
- [ ] `.gitignore` y sin artefactos de build versionados.
