# Postmortem del simulacro DR (laboratorio)

**Fecha:** 22 de octubre de 2026 UTC. **Severidad:** simulacro, sin impacto de usuarios reales.

## Secuencia verificable

- 00:11:50 UTC: respaldo lógico conservado para el ejercicio.
- Después del respaldo: se agregaron dos transacciones, pasando de cinco a siete.
- 00:16:09 UTC: se registró el inicio del incidente simulado; se redujo PostgreSQL en `primary` a cero réplicas.
- Se restauró el respaldo en una nueva base de `dr` y se verificaron cinco registros.
- El tiempo registrado para la recuperación manual fue 129 segundos. Se reactivó `primary` y se verificó que conservaba siete registros.

## Hallazgo y causa

Los dos registros escritos después del respaldo no estaban en el archivo recuperado; la causa es la ventana de protección del backup lógico puntual, no una corrupción en `pg_restore`. La antigüedad del respaldo al inicio fue 259 segundos. La medición de recuperación incluye acciones manuales y no equivale al RTO de una aplicación real.

## Qué funcionó

Integridad SHA-256, restauración en un segundo clúster local, validación SQL y evidencias en `docs/evidencias/dr/`. Posteriormente se comprobó un backup disparado por cron (00:30:01 UTC).

## Acciones pendientes

- Plataforma: alertar si no existe un backup validado reciente y ensayar restauración periódica.
- Datos: evaluar PITR/WAL y almacenamiento fuera del host para reducir dependencia física.
- SRE: medir failover de extremo a extremo con aislamiento de escritor y prueba de aplicación.

**Alcance:** ambos clústeres comparten el mismo host Docker/WSL; no se probó un desastre regional ni se garantizó RPO en incidentes sucesivos.
