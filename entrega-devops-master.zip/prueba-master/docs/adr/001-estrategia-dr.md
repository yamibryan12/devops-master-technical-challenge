# ADR-001: Estrategia de recuperación ante desastres

Estado: Propuesta

## Contexto

La organización opera servicios bancarios digitales y necesita
garantizar continuidad operativa ante incidentes de infraestructura.

Los objetivos definidos son:

- RTO máximo: 4 horas.
- RPO máximo: 15 minutos.

El laboratorio utiliza dos clusters Kubernetes locales para
validar procedimientos de recuperación de PostgreSQL.

Sin embargo, ambos comparten una misma máquina física y no
proporcionan independencia ante fallos regionales.

## Opciones evaluadas

### Opción 1: Activo-activo multirregión

Ventajas:
- Mayor capacidad de continuidad ante fallos regionales.
- Distribución del tráfico entre regiones.
- Posibilidad de reducir tiempos de recuperación.

Desventajas:
- Mayor costo de infraestructura.
- Mayor complejidad operativa.
- Requiere resolver consistencia y concurrencia de datos.
- Necesita mecanismos para evitar escrituras conflictivas.

### Opción 2: Activo-pasivo multirregión

Ventajas:
- Menor complejidad que activo-activo.
- Separación geográfica de infraestructura.
- Procedimientos de recuperación más controlados.
- Compatible con una estrategia de base de datos con
  escritor único.

Desventajas:
- Requiere conmutación ante incidentes.
- Existe riesgo de pérdida de datos no replicados.
- La capacidad de contingencia debe mantenerse preparada.
- Es necesario ejecutar simulacros periódicos.

### Opción 3: Multicloud

Ventajas:
- Reduce la dependencia exclusiva de un proveedor.
- Puede mitigar ciertos fallos específicos del proveedor.

Desventajas:
- Mayor complejidad de networking, identidad y observabilidad.
- Incremento de costos y necesidades operativas.
- Diferencias entre servicios administrados.
- Mayor dificultad para garantizar consistencia de datos.

## Decisión

Se propone una arquitectura activo-pasivo multirregión en Azure.

La región principal ejecutaría AKS y la infraestructura
necesaria para las aplicaciones productivas.

La región secundaria mantendría capacidad de recuperación
y un mecanismo de restauración o replicación de datos.

Se mantendría un único escritor de base de datos en condiciones
normales, evitando escrituras concurrentes entre regiones.

La conmutación requeriría:

1. Confirmar el incidente y activar el procedimiento DR.
2. Aislar o cercar el escritor original.
3. Verificar el estado de los datos disponibles en contingencia.
4. Promover o restaurar el servicio de base de datos.
5. Comprobar conectividad, integridad y dependencias.
6. Redirigir el tráfico hacia la región secundaria.
7. Ejecutar pruebas funcionales y monitorear errores.
8. Registrar los resultados y preparar el retorno controlado.

## Justificación

La estrategia activo-pasivo permite equilibrar continuidad,
costo y complejidad operativa.

Dado el RTO de cuatro horas, no se considera indispensable
una arquitectura activo-activo desde el inicio.

No obstante, el mecanismo de datos deberá demostrar
que cumple el RPO de quince minutos.

La selección final de servicios dependerá de pruebas
de rendimiento, costos, criticidad y requisitos regulatorios.

## Consecuencias

- Necesidad de capacidad de recuperación en otra región.
- Costos adicionales de infraestructura y transferencia.
- Gestión de credenciales y secretos entre regiones.
- Procedimientos de failover y failback.
- Monitoreo de replicación y respaldos.
- Simulacros periódicos con evidencia.
- Controles contra split-brain y pérdida de datos.

## Validación

La solución local demostró que es posible restaurar
PostgreSQL en un segundo cluster.

El simulacro registró:
- Duración del procedimiento: 129 segundos.
- Antigüedad del respaldo: 259 segundos.
- Registros recuperados: 5 de 7.

Estos valores no representan una validación productiva
de RTO/RPO ni una implementación multirregión.

## Criterios de aceptación futuros

- Ejecutar simulacros de indisponibilidad regional.
- Medir RTO desde el incidente hasta la disponibilidad
  funcional de la aplicación.
- Medir el punto efectivo de recuperación de datos.
- Verificar la integridad de transacciones.
- Garantizar que solo exista un escritor activo.
- Demostrar cumplimiento de RTO/RPO bajo fallos definidos.
