# ADR-002: Estrategia de datos y respaldos PostgreSQL

Estado: Propuesta

## Contexto

La plataforma requiere preservar información transaccional
y recuperarla ante incidentes de infraestructura.

Los objetivos son:

- RTO máximo: 4 horas.
- RPO máximo: 15 minutos.

Durante el laboratorio se utilizó PostgreSQL 16.3
en Kubernetes, con almacenamiento persistente.

Se implementó un respaldo lógico mediante pg_dump
y restauración mediante pg_restore.

## Alternativas evaluadas

### Alternativa 1: Backups lógicos mediante pg_dump

Ventajas:
- Fácil implementación.
- Formato portable.
- Recuperación selectiva de objetos.
- Adecuado para laboratorios y bases pequeñas.

Desventajas:
- El tiempo de ejecución aumenta con el volumen de datos.
- No permite por sí solo recuperación continua.
- Puede resultar insuficiente para grandes bases.
- Un intervalo fijo no garantiza automáticamente el RPO.

### Alternativa 2: Backups físicos y archivado WAL

Ventajas:
- Permite recuperación a un instante determinado (PITR).
- Mejora la granularidad de recuperación.
- Facilita estrategias de recuperación más exigentes.

Desventajas:
- Mayor complejidad operativa.
- Requiere gestionar almacenamiento y retención de WAL.
- Necesita validación periódica de respaldos y restauraciones.

### Alternativa 3: Replicación entre regiones

Ventajas:
- Puede reducir el tiempo de recuperación.
- Mantiene una copia de datos más actualizada.
- Puede complementar una estrategia DR.

Desventajas:
- La replicación asíncrona puede presentar retraso.
- La replicación no sustituye los backups.
- Errores lógicos y eliminaciones pueden propagarse.
- Requiere controles de promoción y prevención de split-brain.

## Decisión

Para el laboratorio se mantiene pg_dump como mecanismo
de demostración y recuperación de datos.

Para un entorno productivo bancario se propone combinar:

1. Backups físicos periódicos.
2. Archivado continuo de WAL.
3. Almacenamiento externo y geográficamente separado.
4. Cifrado en tránsito y en reposo.
5. Replicación entre regiones cuando sea viable.
6. Validación periódica mediante restauraciones.
7. Monitoreo y alertas de fallos de backup.
8. Políticas de retención y control de acceso.

## Justificación

La combinación de backups físicos y WAL permite diseñar
una recuperación a un punto en el tiempo.

La replicación puede acelerar la recuperación, pero no
protege por sí sola frente a todos los errores de datos.

Por ese motivo, se recomienda separar la estrategia
de alta disponibilidad de la estrategia de recuperación.

## Implementación del laboratorio

Se implementó:

- backup.sh basado en pg_dump.
- Archivo CUSTOM compatible con pg_restore.
- Validación básica de la estructura del respaldo.
- Hash SHA-256.
- Programación mediante cron.
- Control de concurrencia mediante flock.
- Restauración en un segundo cluster Kubernetes.

La automatización se ejecuta localmente en Ubuntu WSL2.

## Resultados obtenidos

Se validó la recuperación de cinco transacciones.

Antes de la interrupción existían siete transacciones
en el cluster principal.

Las dos operaciones posteriores al backup no estaban
presentes en la restauración.

La antigüedad del respaldo utilizado al iniciar
el incidente fue de 259 segundos.

La restauración técnica fue satisfactoria.

## Riesgos residuales

- Dependencia del equipo físico anfitrión.
- Dependencia de la disponibilidad de WSL2.
- Falta de almacenamiento externo.
- Posibles fallos de programación de cron.
- Ausencia de alertas automáticas.
- No existe archivado WAL continuo.
- No hay recuperación PITR implementada.
- No se ha probado restauración de grandes volúmenes.
- No se ha validado el RPO máximo ante múltiples fallos.

## Criterios de aceptación futuros

- Respaldos almacenados fuera de la región principal.
- Verificación automática de restauración.
- Alertas ante fallos o retrasos de respaldos.
- Pruebas de recuperación con cargas representativas.
- Validación de objetivos RTO/RPO bajo escenarios reales.
- Definición de retención y pruebas de restauración histórica.
- Documentación de responsables y procedimientos operativos.
