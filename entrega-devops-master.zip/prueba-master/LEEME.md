# Prueba técnica DevOps / DevSecOps / SRE — Nivel Master

**Tiempo de trabajo:** 4 horas + sesión en vivo de 60 min con el evaluador.

## Contenido de este paquete
| Archivo | Qué es |
|---------|--------|
| `INSTRUCCIONES-MASTER.md` | **Léelo primero.** Las 5 tareas, el tiempo de cada una y qué esperamos ver. |
| `PIPELINE-ESTANDAR.md` | Estándar de buenas prácticas que debe cumplir todo workflow de GitHub Actions que escribas. |
| `starter/` | Todo lo que necesitas: app Hello World en Java, mocks de herramientas, scripts, datos y ejercicios. |

## Cómo empezar
1. Crea una carpeta de trabajo y copia `starter/` dentro (`git init`; no necesitas GitHub ni cuentas de nube: **todo es local**).
2. Ejecuta `tools/check-env.sh 4` para confirmar que tienes Docker, Minikube, kubectl, Java 21 + Maven, Python 3, shellcheck, `act`, Helm y Ansible.
3. Lee [`starter/README.md`](./starter/README.md) (herramientas, `act`, Minikube) y [`starter/mocks/README.md`](./starter/mocks/README.md).
4. Resuelve las tareas de `INSTRUCCIONES-MASTER.md`. Si el tiempo se agota, entrega lo que tengas y escribe qué harías después: valoramos priorizar.

## Reglas
- Trabajo autónomo. Puedes usar documentación, internet e IA; **lo que no puedas explicar o modificar en vivo no cuenta**.
- Nunca incluyas secretos reales. Los tokens de los mocks son `dummy`; en pipelines deben venir de `secrets.*`.
- Fortify, Checkmarx, SonarQube, Artifactory, Jira, Burp y LoadRunner son **mocks**: evaluamos las **reglas** que decides poner, no el uso de la herramienta real.
- La evidencia va en `docs/evidencias/` (logs y salidas de comandos). Si algo no corrió, dilo.

## Entrega
Carpeta o zip de tu repositorio con: `diagnostico/`, `dr/`, `chaos/`, `anomaly/`, `supply-chain/`, `docs/`, `README.md` y `docs/evidencias/`.
Postmortem del simulacro (1 página) dentro de las 24 h posteriores a la sesión en vivo.
