#!/usr/bin/env bash
# Verifica que tienes lo necesario para tu nivel. Uso: tools/check-env.sh [1|2|3|4]
set -uo pipefail
level="${1:-1}"
need=(git docker minikube kubectl java mvn python3 shellcheck act)
[ "$level" -ge 2 ] && need+=(helm ansible-playbook ansible-lint)
ok=1
for t in "${need[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then printf '  [OK]    %s\n' "$t"; else printf '  [FALTA] %s\n' "$t"; ok=0; fi
done
# promtool: viene en la imagen de Prometheus; no hace falta instalarlo
if [ "$level" -ge 2 ]; then
  docker image inspect prom/prometheus:v2.53.0 >/dev/null 2>&1 \
    && echo "  [OK]    imagen prom/prometheus:v2.53.0 (promtool)" \
    || echo "  [INFO]  promtool: docker pull prom/prometheus:v2.53.0"
fi
exit $((1 - ok))
