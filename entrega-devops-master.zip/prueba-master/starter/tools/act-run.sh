#!/usr/bin/env bash
# Ejecuta tus workflows EN LOCAL con `act` (https://github.com/nektos/act).
#   tools/act-run.sh <evento> [scenario] [-- args extra de act]
#   tools/act-run.sh push clean
#   tools/act-run.sh pull_request dirty -- -j quality-gate
# Guarda la salida en docs/evidencias/act-<evento>-<scenario>.log (úsala como evidencia).
set -euo pipefail
event="${1:?evento: push|pull_request|workflow_dispatch}"; scenario="${2:-clean}"; shift $(( $# >= 2 ? 2 : $# )) || true
[ "${1:-}" = "--" ] && shift
here="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$here/docs/evidencias" /tmp/act-artifacts
log="$here/docs/evidencias/act-${event}-${scenario}.log"
cd "$here"
# Secretos dummy: los mocks solo exigen que existan. NUNCA pongas secretos reales aquí.
act "$event" \
  --eventpath "tools/../events/${event}.json" \
  --env MOCK_SCENARIO="$scenario" \
  --secret SONAR_TOKEN=dummy --secret FORTIFY_TOKEN=dummy --secret CX_TOKEN=dummy \
  --secret JFROG_ACCESS_TOKEN=dummy --secret JIRA_API_TOKEN=dummy --secret BURP_API_KEY=dummy \
  --artifact-server-path /tmp/act-artifacts \
  "$@" 2>&1 | tee "$log"
echo "Log guardado en $log"
