# Starter — todo lo que necesitas (100 % local)

Copia esta carpeta a la raíz de tu repositorio de trabajo (`git init`; no necesitas GitHub para entregar).

| Elemento | Para qué sirve |
|----------|----------------|
| `app/` | **Hello World en Java 21** (solo JDK + Maven): `/` , `/health`, `/ready`, `/greet/{name}`, `/metrics`. No se evalúa; es el workload. |
| `mocks/` | Fortify, Checkmarx, SonarQube, Artifactory/Xray, Jira, Burp y LoadRunner **simulados** (ver [`mocks/README.md`](./mocks/README.md)). |
| `tools/check-env.sh` | Verifica que tienes las herramientas de tu nivel: `tools/check-env.sh 2` |
| `tools/act-run.sh` | Ejecuta tus workflows de GitHub Actions **en local** con [`act`](https://github.com/nektos/act) y guarda el log como evidencia. |
| `tools/loadgen.sh` | Genera tráfico (con % de errores configurable) contra el servicio. |
| `events/` | Eventos de ejemplo para `act` (`push`, `pull_request` con título `DEVOPS-101 ...`, `workflow_dispatch`). |
| `.actrc` | Imágenes para `act`. |
| `k8s-base/` | Prometheus listo para Minikube (Competente/Proficiente) y PostgreSQL para el ejercicio de DR (Master). |
| `ejercicios/` | Archivos de entrada de las tareas de tu nivel (code review, logs de incidente, datasets, workflows ajenos…). |

## Verificación rápida (5 min)

```bash
tools/check-env.sh 1
cd app && mvn -B verify && java -jar target/app.jar &      # curl localhost:8080/
```

## Ejecutar pipelines en local

```bash
tools/act-run.sh pull_request clean      # corre tu workflow con el evento de PR
tools/act-run.sh push dirty              # con datos "sucios": tus gates deben fallar
tools/act-run.sh push clean -- -j build-test   # un job concreto
```
Notas: `act` necesita Docker y descarga las acciones (internet). Los secretos que usa son `dummy`.
Si una acción no funciona en `act` (cache, attest, login a GHCR…) protégela con `if: ${{ !env.ACT }}` y explícalo en tu README.

## Minikube (receta base)

```bash
minikube start --cpus=4 --memory=4096            # Competente+: --cni=calico --addons=metrics-server,ingress
eval "$(minikube docker-env)"                    # construir imágenes directamente dentro de Minikube
docker build -t hello:1.0.0 -f docker/Dockerfile .    # (o: minikube image load hello:1.0.0)
```
Usa `imagePullPolicy: IfNotPresent` con imágenes locales. Para acceder: `kubectl port-forward svc/<svc> 8080:8080`.
