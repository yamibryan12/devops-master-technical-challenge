# Mocks de herramientas

Los mocks **no escanean nada**: leen un fixture JSON y evalúan **tus reglas**. Salida `0` = política cumplida,
`1` = política violada, `2` = error de uso / sin credencial.

```bash
export MOCK_SCENARIO=clean        # clean (default) | dirty  -> datos sin / con hallazgos
export FORTIFY_TOKEN=dummy        # cada herramienta exige su variable (en CI: secrets.*)
                                  # o: export MOCK_REQUIRE_AUTH=0 solo para pruebas locales
```

| Comando (`bin/`) | Simula | Reglas que TÚ defines | Credencial |
|------------------|--------|-----------------------|------------|
| `sonar-scanner-mock --project-key K --gate "..."` | SonarQube Quality Gate | `coverage>=80,bugs<=0,vulnerabilities<=0,code_smells<=N,duplication<=N,security_hotspots_reviewed>=100,security_rating<=1,reliability_rating<=1,maintainability_rating<=N` | `SONAR_TOKEN` |
| `fortify-mock --target DIR --fail-on "critical=0,high=0,medium=10"` | Fortify SAST | máximo permitido por severidad | `FORTIFY_TOKEN` |
| `checkmarx-mock --engine sast\|sca --fail-on "..." [--deny-licenses GPL-3.0,AGPL-3.0]` | Checkmarx SAST / SCA | severidades + licencias denegadas (solo `sca`) | `CX_TOKEN` |
| `burp-mock --target URL --fail-on "..."` | Burp Suite DAST | máximo por severidad | `BURP_API_KEY` |
| `loadrunner-mock --vusers N --duration S --sla "p95_ms<=500,error_rate<=1"` | Pruebas de carga | `p95_ms, p99_ms, error_rate, throughput_rps` | — |
| `jfrog-mock upload --repo R --path P --props "k=v;..."` / `jfrog-mock xray-scan --fail-on "..."` | Artifactory + Xray | build properties de trazabilidad; severidades de Xray | `JFROG_ACCESS_TOKEN` |
| `jira-mock get\|transition\|comment --issue KEY-1 [--status S]` | Jira | key válida (`DEVOPS-101..103` existen) | `JIRA_API_TOKEN` |

Opciones comunes: `--report ruta.json` (guarda el resultado para publicarlo como artifact).

Si no defines reglas el mock imprime una **ADVERTENCIA** y nunca falla: eso cuenta como un gate vacío.

Ejemplo:

```bash
MOCK_SCENARIO=dirty mocks/bin/fortify-mock --target app/src --fail-on "critical=0,high=0" ; echo "exit=$?"   # exit=1
```

Requiere `python3` (3.10+). No uses `jq`/`yq` dentro de los mocks; si los necesitas en tus scripts, instálalos en el job.
