#!/usr/bin/env python3
"""Motor único de los mocks de herramientas DevSecOps (solo librería estándar).

NO ejecuta ninguna herramienta real. Lee un fixture JSON, imprime un resumen y
evalúa las REGLAS que el candidato pasa por línea de comandos. Lo que se evalúa
es qué reglas/umbrales define el candidato, no el uso de la herramienta real.

Códigos de salida:  0 = política cumplida | 1 = política violada | 2 = error de uso / auth

Escenario de datos:  MOCK_SCENARIO=clean (default) | dirty
Autenticación:       cada herramienta exige su variable de entorno (ver TOOLS).
                     En local: export SONAR_TOKEN=dummy ...   o   MOCK_REQUIRE_AUTH=0
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
SEVERITIES = ["critical", "high", "medium", "low"]

TOOLS = {
    "fortify":      {"title": "Fortify SCA (MOCK)",        "env": "FORTIFY_TOKEN",     "fixture": "fortify.json"},
    "checkmarx":    {"title": "Checkmarx One (MOCK)",      "env": "CX_TOKEN",          "fixture": "checkmarx.json"},
    "sonar":        {"title": "SonarQube Scanner (MOCK)",  "env": "SONAR_TOKEN",       "fixture": "sonar.json"},
    "jfrog":        {"title": "JFrog Artifactory (MOCK)",  "env": "JFROG_ACCESS_TOKEN", "fixture": "jfrog.json"},
    "jira":         {"title": "Jira Cloud (MOCK)",         "env": "JIRA_API_TOKEN",    "fixture": "jira.json"},
    "burp":         {"title": "Burp Suite DAST (MOCK)",    "env": "BURP_API_KEY",      "fixture": "burp.json"},
    "loadrunner":   {"title": "LoadRunner (MOCK)",         "env": None,                "fixture": "loadrunner.json"},
}


def die(msg, code=2):
    print(f"[mock] ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def load_fixture(tool):
    path = Path(os.environ.get("MOCK_FIXTURE") or BASE / "fixtures" / TOOLS[tool]["fixture"])
    scenario = os.environ.get("MOCK_SCENARIO", "clean")
    data = json.loads(path.read_text())
    if scenario not in data:
        die(f"escenario '{scenario}' no existe en {path.name} (usa clean|dirty)")
    return data[scenario]


def check_auth(tool):
    var = TOOLS[tool]["env"]
    if var and os.environ.get("MOCK_REQUIRE_AUTH", "1") == "1" and not os.environ.get(var):
        die(f"401 Unauthorized: falta la variable {var}. En CI debe venir de secrets; en local usa un valor dummy.")


def banner(tool, what):
    print(f"==== {TOOLS[tool]['title']} :: {what} ====")
    print(f"scenario={os.environ.get('MOCK_SCENARIO', 'clean')}  ts={datetime.now(timezone.utc).isoformat(timespec='seconds')}")


def write_report(path, payload):
    if path:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(payload, indent=2))
        print(f"[mock] reporte escrito en {path}")


def parse_sev_rules(text):
    """'critical=0,high=0,medium=10'  ->  {'critical':0,'high':0,'medium':10}  (máximo permitido)"""
    rules = {}
    for part in filter(None, (p.strip() for p in (text or "").split(","))):
        m = re.fullmatch(r"(critical|high|medium|low)=(\d+)", part)
        if not m:
            die(f"regla inválida '{part}'. Formato: critical=0,high=0,medium=10")
        rules[m.group(1)] = int(m.group(2))
    return rules


OPS = {
    ">=": lambda a, b: a >= b, "<=": lambda a, b: a <= b, "==": lambda a, b: a == b,
    ">": lambda a, b: a > b, "<": lambda a, b: a < b,
}


def parse_gate_rules(text):
    """'coverage>=80,bugs<=0' -> [('coverage','>=',80.0),...]"""
    rules = []
    for part in filter(None, (p.strip() for p in (text or "").split(","))):
        m = re.fullmatch(r"([a-z_0-9]+)\s*(>=|<=|==|>|<)\s*(-?\d+(?:\.\d+)?)", part)
        if not m:
            die(f"gate inválido '{part}'. Formato: coverage>=80,bugs<=0")
        rules.append((m.group(1), m.group(2), float(m.group(3))))
    return rules


def eval_severity(findings, rules, label):
    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in SEVERITIES}
    print("hallazgos:", ", ".join(f"{s}={counts[s]}" for s in SEVERITIES))
    for f in findings:
        extra = f.get("file") or f.get("url") or f.get("package", "")
        print(f"  - [{f['severity']:<8}] {f.get('id', '?'):<14} {f.get('title', '')}  ({extra})")
    if not rules:
        print("[mock] ADVERTENCIA: no definiste reglas (--fail-on). El escaneo es informativo y NUNCA falla.")
    violations = [f"{s}: {counts[s]} > permitido {mx}" for s, mx in rules.items() if counts[s] > mx]
    print(f"[mock] reglas aplicadas ({label}): {rules or 'ninguna'}")
    return counts, violations


def eval_gate(metrics, rules):
    violations = []
    for name, op, val in rules:
        if name not in metrics:
            die(f"métrica desconocida '{name}'. Disponibles: {', '.join(sorted(metrics))}")
        ok = OPS[op](metrics[name], val)
        print(f"  {'OK  ' if ok else 'FAIL'} {name} {op} {val:g}   (actual={metrics[name]})")
        if not ok:
            violations.append(f"{name} {op} {val:g} (actual={metrics[name]})")
    if not rules:
        print("[mock] ADVERTENCIA: no definiste gates (--gate). El resultado es informativo y NUNCA falla.")
    return violations


def finish(tool, violations, report, payload):
    payload.update({"tool": tool, "violations": violations, "passed": not violations})
    write_report(report, payload)
    if violations:
        print("[mock] RESULTADO: POLÍTICA VIOLADA")
        for v in violations:
            print(f"   x {v}")
        sys.exit(1)
    print("[mock] RESULTADO: OK")


# ---------------------------------------------------------------- comandos
def cmd_severity_scan(tool, args):
    check_auth(tool)
    data = load_fixture(tool)
    engine = getattr(args, "engine", None)
    findings = data[engine] if engine else data["findings"]
    banner(tool, f"scan {engine or ''}".strip())
    if engine == "sca" and args.deny_licenses:
        denied = {l.strip() for l in args.deny_licenses.split(",")}
        bad = [f for f in findings if f.get("license") in denied]
        for f in bad:
            print(f"  - [license ] {f['package']} usa licencia denegada {f['license']}")
    else:
        bad = []
    counts, violations = eval_severity(findings, parse_sev_rules(args.fail_on), tool)
    violations += [f"licencia denegada: {f['package']} ({f['license']})" for f in bad]
    finish(tool, violations, args.report, {"counts": counts, "findings": findings})


def cmd_sonar(args):
    check_auth("sonar")
    m = load_fixture("sonar")
    banner("sonar", f"scan project={args.project_key}")
    print("métricas:", json.dumps(m))
    finish("sonar", eval_gate(m, parse_gate_rules(args.gate)), args.report, {"metrics": m})


def cmd_loadrunner(args):
    m = load_fixture("loadrunner")
    banner("loadrunner", f"run vusers={args.vusers} duration={args.duration}s")
    print("métricas:", json.dumps(m))
    finish("loadrunner", eval_gate(m, parse_gate_rules(args.sla)), args.report, {"metrics": m})


def cmd_jfrog(args):
    check_auth("jfrog")
    data = load_fixture("jfrog")
    if args.action == "upload":
        if not args.repo or not args.path:
            die("upload requiere --repo y --path")
        banner("jfrog", f"upload {args.path} -> {args.repo}")
        print(f"  props: {args.props or '(sin build properties: se recomienda build.name, build.number, vcs.revision)'}")
        print("  checksum sha256:", data["upload"]["sha256"])
        finish("jfrog", [], args.report, {"upload": data["upload"], "repo": args.repo, "props": args.props})
    else:
        banner("jfrog", "xray scan")
        counts, v = eval_severity(data["xray"], parse_sev_rules(args.fail_on), "xray")
        finish("jfrog", v, args.report, {"counts": counts, "findings": data["xray"]})


def cmd_jira(args):
    check_auth("jira")
    data = load_fixture("jira")
    banner("jira", args.action)
    key = args.issue or ""
    if not re.fullmatch(r"[A-Z][A-Z0-9]+-\d+", key):
        die(f"issue key inválida '{key}' (esperado p.ej. DEVOPS-123)", 1)
    known = {i["key"]: i for i in data["issues"]}
    if key not in known:
        die(f"404: {key} no existe en el proyecto mock", 1)
    if args.action == "transition":
        print(f"  POST /rest/api/3/issue/{key}/transitions  -> '{args.status}' (simulado)")
    elif args.action == "comment":
        print(f"  POST /rest/api/3/issue/{key}/comment      -> {args.body!r} (simulado)")
    else:
        print(f"  GET  /rest/api/3/issue/{key} -> {known[key]}")
    finish("jira", [], args.report, {"issue": key, "action": args.action})


# ---------------------------------------------------------------- CLI
def main():
    p = argparse.ArgumentParser(prog="mocktool")
    sub = p.add_subparsers(dest="tool", required=True)

    for t in ("fortify", "burp"):
        s = sub.add_parser(t)
        s.add_argument("--target", help="ruta (SAST) o URL (DAST)")
        s.add_argument("--fail-on", default="", help="máximos permitidos: critical=0,high=0,medium=10")
        s.add_argument("--report")

    s = sub.add_parser("checkmarx")
    s.add_argument("--engine", choices=["sast", "sca"], required=True)
    s.add_argument("--fail-on", default="")
    s.add_argument("--deny-licenses", default="", help="solo engine sca: GPL-3.0,AGPL-3.0")
    s.add_argument("--report")

    s = sub.add_parser("sonar")
    s.add_argument("--project-key", required=True)
    s.add_argument("--gate", default="", help="quality gate: coverage>=80,bugs<=0")
    s.add_argument("--report")

    s = sub.add_parser("loadrunner")
    s.add_argument("--vusers", type=int, default=10)
    s.add_argument("--duration", type=int, default=60)
    s.add_argument("--sla", default="", help="p95_ms<=500,error_rate<=1")
    s.add_argument("--report")

    s = sub.add_parser("jfrog")
    s.add_argument("action", choices=["upload", "xray-scan"])
    s.add_argument("--repo")
    s.add_argument("--path")
    s.add_argument("--props")
    s.add_argument("--fail-on", default="")
    s.add_argument("--report")

    s = sub.add_parser("jira")
    s.add_argument("action", choices=["get", "transition", "comment"])
    s.add_argument("--issue")
    s.add_argument("--status", default="")
    s.add_argument("--body", default="")
    s.add_argument("--report")

    a = p.parse_args()
    if a.tool in ("fortify", "burp"):
        check_auth(a.tool)
        data = load_fixture(a.tool)
        banner(a.tool, f"scan {a.target or ''}")
        counts, v = eval_severity(data["findings"], parse_sev_rules(a.fail_on), a.tool)
        finish(a.tool, v, a.report, {"counts": counts, "findings": data["findings"]})
    elif a.tool == "checkmarx":
        cmd_severity_scan("checkmarx", a)
    elif a.tool == "sonar":
        cmd_sonar(a)
    elif a.tool == "loadrunner":
        cmd_loadrunner(a)
    elif a.tool == "jfrog":
        cmd_jfrog(a)
    elif a.tool == "jira":
        cmd_jira(a)


if __name__ == "__main__":
    main()
