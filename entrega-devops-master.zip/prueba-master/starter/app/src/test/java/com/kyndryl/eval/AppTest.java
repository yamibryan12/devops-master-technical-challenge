package com.kyndryl.eval;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.sun.net.httpserver.HttpServer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AppTest {
    static HttpServer server;
    static String base;
    static final HttpClient CLIENT = HttpClient.newHttpClient();

    @BeforeAll
    static void up() throws Exception {
        server = App.start(0);
        base = "http://localhost:" + server.getAddress().getPort();
    }

    @AfterAll
    static void down() { server.stop(0); }

    private HttpResponse<String> get(String path) throws Exception {
        return CLIENT.send(HttpRequest.newBuilder(URI.create(base + path)).build(),
            HttpResponse.BodyHandlers.ofString());
    }

    @Test
    void helloWorld() throws Exception {
        assertEquals("{\"message\":\"Hello, World!\"}", get("/").body());
    }

    @Test
    void health() throws Exception {
        var r = get("/health");
        assertEquals(200, r.statusCode());
        assertTrue(r.body().contains("\"status\":\"ok\""));
    }

    @Test
    void greet() throws Exception {
        assertEquals("{\"message\":\"Hello, Ana!\"}", get("/greet/Ana").body());
    }

    @Test
    void greetRejectsInvalidName() throws Exception {
        assertEquals(400, get("/greet/a%20b%3Cscript%3E").statusCode());
    }
}
