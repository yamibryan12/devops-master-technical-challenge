# Contexto de la organización (ficticia)

- 12 squads, ~85 ingenieros, banca digital regulada (auditoría trimestral).
- Jenkins central único (1 controller, 6 agentes) con 5 squads; GitHub Actions en 5; 2 squads sin pipeline.
- Un único clúster AKS de producción, una región. Sin DR probado. RTO objetivo declarado: 4h; RPO: 15min.
- Presupuesto de plataforma: 6 FTE (SRE+DevOps). Objetivo del CIO: reducir Change Failure Rate global a <15% y
  duplicar frecuencia de despliegue en 12 meses sin aumentar incidentes sev1.
- Auditoría pidió evidencia de escaneo SAST/SCA en el 100% de los releases.
